Nama  : Anisa Fitri
NIM   : 2109116081
Kelas : B2 2021

Tema Website yang saya ambil adalah Pinjaman Online, yaitu platform untuk melakukan pinjaman secara cepat. pinjaman kredit berbasis online ini menawarkan kemudahan sekaligus kecepatan yang tidak ditemukan pada kredit offline pada umumnya.

Pada Halaman pertama atau biasa yang disebut Home, ada header yang berisi judul Pinjolku dengan logonya, Lalu ada navbar yang bersis aboutus, form dan pinjaman. dan ada Video iklan youtube yanag berisi iklan tentanng waspada pinjol ilegal.

Pada Halaman kedua yaitu Aboutus, berisi berita tentang pinjol dan tata cara sebelum registrasi dan ada beberapa gambar testimoni dari customers yang telah menggunakan website pinjol ini.

Pada Halaman ketiga yaitu Form, berisi syarat-syarat untuk mengajukan pinjaman lalu dilanjutkan untuk registrasi terlebih dahulu. dengan mengisi Nama yang sesuai dengan di KTP, kedua No Handphone, alamat email, password, memilih jenis kelamin. jika sudah selesai mengisi klik daftar dan akan lamgsumg diarahkan ke halaman selanjutnya yaitu halaman Pinjaman.

Pada Halaman keempat yaitu Pinjaman, halaman yang berisikan Nominal yang akan dipinjam, lalu bunga yang dapat dipilih dengan select option, Lalu Tenor juga dipilih dengan cara select option. Lalu ada choose file untuk menanmbahkan file. Lalu sebelum daftar ada pemastian dari data yang sudah tersedia menggunakan check box dan terakhir ada klik button daftar.